#include <stdio.h>
#include <string.h>
#include "util.h"
#include "symbol.h"
#include "absyn.h"
#include "escape.h"
#include "table.h"

void Esc_findEscape(A_exp exp) {
	//your code here	
}
