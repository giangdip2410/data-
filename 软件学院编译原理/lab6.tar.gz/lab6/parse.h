/* function prototype from parse.c */

#ifndef PARSE_H
#define PARSR_H

A_exp parse(string fname);

#endif
